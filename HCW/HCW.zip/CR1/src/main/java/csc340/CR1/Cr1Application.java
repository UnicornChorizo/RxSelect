package csc340.CR1;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Cr1Application {

	/**
	 * Application starting point
	 * @param args
	 */
	public static void main(String[] args) {
		SpringApplication.run(Cr1Application.class, args);
	}

}
