package csc340.CR1;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Cr1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
