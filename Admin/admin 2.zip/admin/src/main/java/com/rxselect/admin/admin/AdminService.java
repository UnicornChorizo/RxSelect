package com.rxselect.admin.admin;

import com.rxselect.admin.common.User;
import com.rxselect.admin.common.UserRepository;
import com.rxselect.admin.patient.Patient;
import com.rxselect.admin.patient.PatientRepository;
import jakarta.transaction.Transactional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.List;
import java.util.Optional;

@Service
public class AdminService {
    private final PatientRepository patientRepository;
    private final UserRepository userRepository;

    @Autowired
    public AdminService(PatientRepository patientRepository, UserRepository userRepository) {
        this.patientRepository = patientRepository;
        this.userRepository = userRepository;
    }

    @Transactional
    public Patient addPatient(Patient patient) {
        // If the user is new (no ID), save the user first
        if (patient.getUser().getUserId() == null) {
            User savedUser = userRepository.save(patient.getUser());
            patient.setUser(savedUser);
        }
        // Now save the patient
        return patientRepository.save(patient);
    }
    public List<Patient> getAllPatients() {
        return patientRepository.findAll();
    }

    @Transactional
    public Patient updatePatient(Long patientId, Patient patientDetails) {
        Patient patient = patientRepository.findById(patientId)
                .orElseThrow(() -> new RuntimeException("Patient not found"));

        User user = patient.getUser();
        user.setFirstName(patientDetails.getUser().getFirstName());
        user.setLastName(patientDetails.getUser().getLastName());
        user.setEmail(patientDetails.getUser().getEmail());

        patient.setSex(patientDetails.getSex());
        patient.setDob(patientDetails.getDob());

        return patientRepository.save(patient);
    }
    public void deletePatient(Long patientId) {
        patientRepository.deleteById(patientId);
    }


    public Optional<Patient> findPatientById(Long id) {
        return patientRepository.findById(id);
    }

}
