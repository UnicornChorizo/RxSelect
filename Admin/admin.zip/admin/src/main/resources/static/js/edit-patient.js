document.addEventListener('DOMContentLoaded', function () {
    // Load patient data when the document is fully loaded
    loadPatientData();
});

document.getElementById('editPatientForm').addEventListener('submit', function (event) {
    event.preventDefault(); // Prevent the form from submitting normally

    // Retrieve values from form inputs
    const patientId = document.getElementById('editPatientId').value;
    const patientData = {
        // Assuming the server expects a 'user' object within 'patientData'
        user: {
            firstName: document.getElementById('patientName').value.split(' ')[0],
            lastName: document.getElementById('patientName').value.split(' ')[1] || '',
            // Add other user properties if needed
        },
        sex: document.getElementById('patientSex').value,
        dob: document.getElementById('patientDob').value
    };

    // AJAX request to the server to update the patient
    fetch(`http://localhost:8080/admin/patients/${patientId}`, {
        method: 'PUT', // Use 'PUT' to update the entire patient or 'PATCH' for partial update
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify(patientData) // Convert patientData to JSON
    })
        .then(response => {
            if (!response.ok) {
                throw new Error('Network response was not ok');
            }
            return response.json();
        })
        .then(updatedPatient => {
            console.log('Patient updated successfully:', updatedPatient);
            // Redirect back to the patient list or display a success message
            window.location.href = 'admin.html';
        })
        .catch(error => {
            console.error('Error updating patient:', error);
            alert('Error updating patient. See console for more details.');
        });
});

function loadPatientData() {
    // Extract the patient ID from the URL query parameters
    const urlParams = new URLSearchParams(window.location.search);
    const patientId = urlParams.get('patientId');

    // Check if patientId is not null and make a GET request to the server
    if (patientId) {
        fetch(`http://localhost:8080/admin/patients/${patientId}`)
            .then(response => response.json())
            .then(patient => {
                // Populate form fields with patient data
                document.getElementById('editPatientId').value = patient.patientId;
                document.getElementById('patientName').value = `${patient.user.firstName} ${patient.user.lastName}`;
                document.getElementById('patientSex').value = patient.sex;
                // Format date as YYYY-MM-DD for the date input field
                document.getElementById('patientDob').value = patient.dob.substring(0, 10);
            })
            .catch(error => {
                console.error('Error loading patient data:', error);
                alert('Error loading patient data. See console for more details.');
            });
    } else {
        console.error('Patient ID not found in URL');
    }
}
